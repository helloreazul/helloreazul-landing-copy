# helloreazul landing copy

A reusable, product-agnostic landing page research and conversion copywriting workflow for Claude and ChatGPT.

## Repository layout

- `claude-skill/helloreazul-landing-copy/SKILL.md`: Claude skill source.
- `chatgpt-skill/`: ChatGPT skills-only plugin source, including `plugin.json`, `agents/openai.yaml`, and the skill.
- `shared/master-prompt.md`: Reusable master prompt.

## Workflow

1. Ask for **Product Research Document Link** and **Existing Landing Page Structure Link**.
2. Identify the product from the research document, then verify its available features in official sources.
3. Analyze search intent, relevant competitors, reviews, and GSC data only where accessible.
4. Preserve the reference landing page section sequence and create an original product-specific strategy and outline.
5. Wait for the user's approval before drafting complete landing page copy.
6. Never invent statistics, user reviews, search metrics, or released features.

## Use in Claude

Package the `claude-skill/helloreazul-landing-copy/` folder as a ZIP with `helloreazul-landing-copy/SKILL.md` inside and upload it in Claude's skills settings where supported.

## Use in ChatGPT

The `chatgpt-skill/` folder contains the plugin's portable manifest and skill. Package that folder's **contents** as one ZIP for plugin import. A private ChatGPT plugin may also be opened from the account where it was created. Updating this GitHub repository does not automatically update an installed plugin.

## Notes

- Google Docs, website, and Google Search Console access depend on the environment's available connectors, permissions, and supplied files.
- Keep proprietary product research documents, customer data, account tokens, and private GSC exports out of any public repository.
- The master prompt and skill files are editable source; GitHub stores them but does not itself execute them.
