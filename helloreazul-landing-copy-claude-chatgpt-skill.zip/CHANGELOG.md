# Changelog

## 1.0.0 - 2026-11-05

- Added Claude landing page skill.
- Added ChatGPT skills-only plugin package.
- Added shared master prompt and repository documentation.
